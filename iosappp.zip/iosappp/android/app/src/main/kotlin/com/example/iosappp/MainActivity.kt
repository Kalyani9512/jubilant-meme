package com.example.iosappp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
